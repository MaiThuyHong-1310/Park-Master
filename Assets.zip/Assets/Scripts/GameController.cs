using R3;
using UnityEngine;
using UnityEngine.UI;

public class GameController : Singleton<GameController>
{
    [SerializeField] CarSelectionManager m_carSelectionManager;
    [SerializeField] PathDrawer m_pathDrawer;


    [Header("Level Settings")]
    [SerializeField] int m_startLevelId = 0;

    Level m_currentLevel;

    int m_currentLevelId;

    bool m_changingLevel;

    private void Start()
    {
        m_currentLevelId = 0;

        LoadLevel(m_currentLevelId);

        m_carSelectionManager.onCollectingAllCar += OnWinLevel;

    }

    public void LoadLevel(int id)
    {
        int totalLevel = 2;

        m_carSelectionManager.Clear();

        if (m_currentLevel != null)
        {
            m_currentLevel.Dispose();
            Destroy(m_currentLevel.gameObject);
            //m_currentLevel = null;
        }

        m_currentLevel = Instantiate(Resources.Load<GameObject>($"Level{id % totalLevel}")).GetComponent<Level>();
        m_currentLevel.Init();
        m_carSelectionManager.SetCarsForLevel(m_currentLevel.Cars.ToArray());
    }

    void OnWinLevel(int count)
    {
        Debug.Log($"WIN COLLECTING {count} cars");

        NextLevel();
    }

    void OnLoseLevel()
    {

    }

    public void ReplayLevel()
    {

    }

    public void NextLevel()
    {
        //LoadLevel(m_currentLevel+1);
        if (m_changingLevel) return;
        m_changingLevel = true;

        m_currentLevelId++;

        LoadLevel(m_currentLevelId);

        m_changingLevel = false;
    }
}
