using UnityEngine;
using R3;
using TMPro;
using System.Collections.Generic;
using System.Collections;

public class HighscoreTextView : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI m_text;
    CompositeDisposable m_bindings = new();

    /*IEnumerator Start()
    {
        yield return new WaitForSeconds(1f);
        GameController.Instance.HighScore.Subscribe((highscore) =>
        {
            m_text.text = highscore.ToString();
        }).AddTo(m_bindings);   
    }*/

    private void OnDestroy()
    {
        m_bindings.Clear();
    }
}
