using UnityEngine;

public class Coin : MonoBehaviour
{
    [SerializeField] Car car;
    //Transform m_coinBody;
    Vector3 carBodyPos;
    float minDistanceCarAndCoin = 1.5f;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        carBodyPos = car.GetCarBodyPos();
        //Debug.Log("POSITION OF COIN: " + this.transform.position);
        Debug.Log("POSITION OF CAR: " + carBodyPos);
        Debug.Log("DISTANCE BETWEEN CAR AND COIN: " + Vector3.Distance(this.transform.position, carBodyPos));
        if (Vector3.Distance(this.transform.position, carBodyPos) < minDistanceCarAndCoin)
        {
            Debug.Log("DESTROY COIN");
            Destroy(gameObject);
        }
    }
}
