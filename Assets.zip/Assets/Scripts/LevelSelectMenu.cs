using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelSelectMenu : MonoBehaviour
{
    public void LoadLevel0()
    {
        //SceneManager.LoadScene("Level0");
    }

    public void LoadLevel1()
    {
        //SceneManager.LoadScene("Level1");
    }
}
